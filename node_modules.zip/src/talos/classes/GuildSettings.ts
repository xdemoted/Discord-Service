interface GuildSettings {
    leveling: boolean;
    
}