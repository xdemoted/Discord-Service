export enum Operator {
    MULTIPLY = "*",
    DIVIDE = "/",
    ADD = "+",
    SUBTRACT = "-",
    POWER = "^",
    MODULO = "%",
    SET = "="
}